I ran into many differnet bugs and ran into many issues suddenly, and ran out of times so I wasn't able to impliment my login/logout function. 

As for the CRUD services, if you go into the website, you can press the button of 'add to cart' and if you were to scroll down, you can see the items you've added being shown in the cart. 
In the cart you can change the quantity as well, and you can remove the items as well.
When you change the quantity, the total price in the cart changes as well. 

There are three different page. 
'HOME', 'STORE', 'ABOUT' 

You can press the facebook, spotify and youtube to head into different websites. 